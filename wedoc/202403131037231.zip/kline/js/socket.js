function createWebSocket(url, onMessageCallback) {
  // 创建 WebSocket 对象
  var ws = new WebSocket(url);
  
  // 心跳检测定时器
  var heartbeatTimer = null;

  // 连接成功时触发
  ws.onopen = function() {
    console.log('WebSocket 连接成功');
    // 开始心跳检测
    startHeartbeat();
  };

  // 收到消息时触发
  ws.onmessage = function(event) {
    console.log('收到消息：', event.data);
    // 调用外部处理函数
    if (typeof onMessageCallback === 'function') {
      onMessageCallback(event.data);
    }
  };

  // 连接关闭时触发
  ws.onclose = function(event) {
    console.log('WebSocket 连接关闭');
    // 清除心跳检测定时器
    clearInterval(heartbeatTimer);
    // 重连
    reconnect();
  };

  // 发生错误时触发
  ws.onerror = function(event) {
    console.error('WebSocket 发生错误');
    // 清除心跳检测定时器
    clearInterval(heartbeatTimer);
    // 重连
    reconnect();
  };

  // 发送消息
  function sendMessage(message) {
    ws.send(message);
    console.log('发送消息：', message);
  }

  // 开始心跳检测
  function startHeartbeat() {
    heartbeatTimer = setInterval(function() {
      // 发送心跳消息
      sendMessage('ping');
    }, 5000); // 每隔 5 秒发送一次心跳消息
  }

  // 重连
  function reconnect() {
    // 重连间隔时间
    var reconnectInterval = 3000; // 3 秒
    setTimeout(function() {
      console.log('重新连接 WebSocket');
      // 创建新的 WebSocket 连接
      createWebSocket(url, onMessageCallback);
    }, reconnectInterval);
  }

  // 返回 WebSocket 对象和发送消息的方法
  return {
    ws: ws,
    sendMessage: sendMessage
  };
}

// // 使用示例
// var ws = createWebSocket('ws://localhost:8080', function(message) {
//   // 在此处处理收到的消息
//   console.log('处理收到的消息：', message);
// });
