const dark = {
	tipsColor: '#929AA5',
	textColor: '#ffffff',
	gridColor: '#292929',
	axisLineColor: '#333333',
	crossTextBackgroundColorDark: '#373a40',
}
const light = {
	tipsColor: '#222222',
	textColor: '#999999',
	gridColor: '#ededed',
	axisLineColor: '#DDDDDD',
	crossTextBackgroundColorDark: '#686d76',
}


const getThemeOptions = (theme) => {
	const themeData = theme === 'dark' ? dark : light;
	return {
		grid: {
			horizontal: {
				color: themeData.gridColor
			},
			vertical: {
				color: themeData.gridColor
			}
		},
		candle: {
			// 蜡烛图类型 'candle_solid'|'candle_stroke'|'candle_up_stroke'|'candle_down_stroke'|'ohlc'|'area'
			type: 'candle_solid',
			// 蜡烛柱
			// bar: {
			// 	upColor: '#2DC08E',
			// 	downColor: '#F92855',
			// 	noChangeColor: '#888888',
			// 	upBorderColor: '#2DC08E',
			// 	downBorderColor: '#F92855',
			// 	noChangeBorderColor: '#888888',
			// 	upWickColor: '#2DC08E',
			// 	downWickColor: '#F92855',
			// 	noChangeWickColor: '#888888'
			// },
			priceMark: {
				// high: {
				// 	color: textColor
				// },
				// low: {
				// 	color: textColor
				// },
				show: true,
				// 最高价标记
				high: {
					show: true,
					color: themeData.textColor,
					textOffset: 5,
					textSize: 10,
					textFamily: 'Helvetica Neue',
					textWeight: 'normal'
				},
				// 最低价标记
				low: {
					show: true,
					color: themeData.textColor,
					textOffset: 5,
					textSize: 10,
					textFamily: 'Helvetica Neue',
					textWeight: 'normal',
				},
				// 最新价标记
				last: {
					show: true,
					upColor: '#2DC08E',
					downColor: '#F92855',
					noChangeColor: '#888888',
					line: {
						show: true,
						// 'solid' | 'dashed'
						style: 'dashed',
						dashedValue: [4, 4],
						size: 1
					},
					text: {
						show: true,
						// 'fill' | 'stroke' | 'stroke_fill'
						style: 'fill',
						size: 12,
						paddingLeft: 4,
						paddingTop: 4,
						paddingRight: 4,
						paddingBottom: 4,
						// 'solid' | 'dashed'
						borderStyle: 'solid',
						borderSize: 1,
						borderDashedValue: [2, 2],
						color: '#FFFFFF',
						family: 'Helvetica Neue',
						weight: 'normal',
						borderRadius: 2
					}
				}
			},
			tooltip: {
				// 'always' | 'follow_cross' | 'none'
				showRule: 'follow_cross',
				// 'standard' | 'rect'
				showType: 'rect',
				// 自定义显示，可以是回调方法也可以是数组，当是一个方法时，需要返回一个数组
				// 数组的子项类型为 { title, value }
				// title和value可以是字符串或者对象，对象类型为 { text, color }
				// title 或者 title.text 可以是国际化的 key，
				// value 或者 value.text 支持字符串模版
				// 例如：想显示时间，开盘和收盘，配置[{ title: 'time', value: '{time}' }, { title: 'open', value: '{open}' }, { title: 'close', value: '{close}' }]
				// custom: [{
				// 	title: 'time',
				// 	value: '{time}'
				// }, {
				// 	title: 'open',
				// 	value: '{open}'
				// }, {
				// 	title: 'close',
				// 	value: '{close}'
				// }],
				defaultValue: 'n/a',
				rect: {
					// 'fixed' | 'pointer'
					position: 'pointer',
					paddingLeft: 0,
					paddingRight: 0,
					paddingTop: 0,
					paddingBottom: 6,
					offsetLeft: 8,
					offsetTop: 8,
					offsetRight: 8,
					offsetBottom: 8,
					borderRadius: 4,
					borderSize: 1,
					borderColor: 'rgba(0,0,0,0.9)',
					color: 'rgba(0, 0, 0, 0.7)'
				},
				text: {
					size: 12,
					family: 'Helvetica Neue',
					weight: 'normal',
					color: themeData.textColor,
					marginLeft: 6,
					marginTop: 6,
					marginRight: 6,
					marginBottom: 0
				},
			}
		},
		technicalIndicator: {
			tooltip: {
				text: {
					color: themeData.textColor
				},

			}
		},
		xAxis: {
			axisLine: {
				color: themeData.axisLineColor
			},
			tickLine: {
				color: themeData.axisLineColor
			},
			tickText: {
				color: themeData.tipsColor,
				size: 10,
			}
		},
		yAxis: {
			axisLine: {
				color: themeData.axisLineColor
			},
			tickLine: {
				color: themeData.axisLineColor
			},
			tickText: {
				color: themeData.tipsColor,
				size: 10,
			}
		},
		separator: {
			color: themeData.axisLineColor
		},
		crosshair: {
			horizontal: {
				line: {
					color: themeData.crossLineColor
				},
				text: {
					backgroundColor: themeData.crossTextBackgroundColor
				}
			},
			vertical: {
				line: {
					color: themeData.crossLineColor
				},
				text: {
					backgroundColor: themeData.crossTextBackgroundColor
				}
			}
		},
	}
}
