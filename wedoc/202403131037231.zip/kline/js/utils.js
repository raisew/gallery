function genOneData(timestamp = new Date().getTime()) {
  let basePrice = 5000
  timestamp = Math.floor(timestamp / 1000 / 60) * 60 * 1000 - length * 60 * 1000
  const prices = []
  for (let j = 0; j < 4; j++) {
    prices.push(basePrice + Math.random() * 60 - 30)
  }
  prices.sort()
  const open = +(prices[Math.round(Math.random() * 3)].toFixed(2))
  const high = +(prices[3].toFixed(2))
  const low = +(prices[0].toFixed(2))
  const close = +(prices[Math.round(Math.random() * 3)].toFixed(2))
  const volume = Math.round(Math.random() * 100) + 10
  const turnover = (open + high + low + close) / 4 * volume
  return { timestamp, open, high, low, close, volume, turnover };
}

function genData(length = 100, timestamp = new Date().getTime()) {
  let basePrice = 5000
  timestamp = Math.floor(timestamp / 1000 / 60) * 60 * 1000 - length * 60 * 1000
  const dataList = []
  for (let i = 0; i < length; i++) {
    const prices = []
    for (let j = 0; j < 4; j++) {
      prices.push(basePrice + Math.random() * 60 - 30)
    }
    prices.sort()
    const open = +(prices[Math.round(Math.random() * 3)].toFixed(2))
    const high = +(prices[3].toFixed(2))
    const low = +(prices[0].toFixed(2))
    const close = +(prices[Math.round(Math.random() * 3)].toFixed(2))
    const volume = Math.round(Math.random() * 100) + 10
    const turnover = (open + high + low + close) / 4 * volume
    dataList.push({ timestamp, open, high, low, close, volume, turnover })

    basePrice = close
    timestamp += 60 * 1000
  }
  return dataList
}

function getParameterByName(name) {
  // 获取查询参数字符串
  var queryString = window.location.search;
  // 解析查询参数字符串
  var searchParams = new URLSearchParams(queryString);
  // 获取指定参数的值
  var paramValue = searchParams.get(name);
  return paramValue;
}