<template>
	<mypage>
		第二个
		<com-tabbar :index="1"></com-tabbar>
	</mypage>
</template>

<script setup>
	import {
		reactive,
		ref,
		getCurrentInstance,
	} from 'vue'

	import {
		onLoad,
		onShow,
	} from '@dcloudio/uni-app'

	const {
		proxy
	} = getCurrentInstance();

	onLoad(() => {

	})
	onShow(() => {

	})
</script>

<style lang="scss" scoped>

</style>