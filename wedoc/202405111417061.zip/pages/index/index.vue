<template>
	<mypage>
		<mynavbar :is-back="false" title="首页"></mynavbar>
		<com-tabbar :index="0"></com-tabbar>
	</mypage>
</template>
<script setup>

</script>