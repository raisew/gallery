import state from "./state"

const mutations = {
	setTheme: (state, name) => {
		state.themeName = name;
	},
	setToken: (state, data) => {
		state.token = data;
	},
	setLang: (state, data) => {
		state.lang = data;
	},
	setAssetVisible: (state, data) => {
		state.assetVisible = data;
	},
	setConfigData: (state, data) => {
		state.configData = data;
	},
	setUserinfo: (state, data) => {
		state.userinfo = data;
	},
	rmStore: (state) => {
		state.token = '';
		state.userinfo = {};
	}
}
export default mutations