## NoNetwork 无网络提示

> **组件名：uv-no-network**

该组件在没有任何网络的情况下，显示在内容上方，无需任何配置，引入即可，内部自动处理所有功能和事件。

### <a href="https://www.uvui.cn/components/noNetwork.html" target="_blank">查看文档</a>

### [完整示例项目下载 | 关注更多组件](https://ext.dcloud.net.cn/plugin?name=uv-ui)

#### 如使用过程中有任何问题，或者您对uv-ui有一些好的建议，欢迎加入 uv-ui 交流群：<a href="https://ext.dcloud.net.cn/plugin?id=12287" target="_blank">uv-ui</a>、<a href="https://www.uvui.cn/components/addQQGroup.html" target="_blank">官方QQ群</a>
