<template>
	<view>
		<view class="position-fixed top-0 lef-0 status-bar bgc-header"></view>
		<view class="status-bar"></view>
	</view>
</template>

<script setup>

</script>

<style>

</style>