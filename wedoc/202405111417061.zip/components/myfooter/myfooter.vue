<template>
	<view>
		<view class="myfooter safe-area-inset-bottom" style="max-width: 540px; left: 50%; transform: translateX(-50%);"
			id="myfooter" :style="{'z-index': zIndex}" :class="[className]">
			<slot></slot>
		</view>
		<view class="footer-placeholder safe-area-inset-bottom">
			<view :style="{'height': myfooterH + 'px'}"></view>
		</view>
	</view>
</template>

<script setup>
	import {
		ref,
		onMounted
	} from "vue"
	const props = defineProps({
		zIndex: [String, Number],
		className: {
			type: String,
			default: ''
		},
	})
	const myfooterH = ref(0)
	onMounted(() => {
		const query = uni.createSelectorQuery();
		query.select('#myfooter').boundingClientRect(data => {
			myfooterH.value = data.height;
		}).exec();
	})
</script>

<style lang="scss" scoped>
	.myfooter {
		position: fixed;
		bottom: 0;
		left: 0;
		z-index: 998;
		width: 100%;
	}
</style>