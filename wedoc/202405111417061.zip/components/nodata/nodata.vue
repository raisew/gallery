<template>
	<view class="flex flex-column flex-justify-center flex-align-center w-100 h-600px">
		<slot>
			<u-image :src="img" height="240" width="auto" mode="heightFix" bg-color="transparent"></u-image>
		</slot>
		<text class="msg">{{msg || $t('No_data')}}</text>
	</view>
</template>

<script setup>
	import {
		reactive,
		ref,
		getCurrentInstance,
		watch,
		computed,
		nextTick
	} from 'vue';
	import nodata from "./nodata.png";
	const {
		proxy
	} = getCurrentInstance();
	const props = defineProps({
		msg: {
			type: String,
			default: '',
		},
		img: {
			type: String,
			default: nodata
		},
		type: {
			type: [String, Number],
		}
	})
</script>

<style lang="scss">
	.msg {
		margin-top: 20rpx;
		color: rgba(125, 125, 125, 0.5);
	}
</style>