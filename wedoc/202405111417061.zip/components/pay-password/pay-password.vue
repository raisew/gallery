<template>
	<u-modal v-model="show" title="交易密码" show-confirm-button show-cancel-button blur="1" confirm-text="确认"
		cancel-text="取消" @cancel="$emit('close')" @confirm="clickConfirm">
		<view class="pd-32">
			<view class="com-border">
				<u-input type="password" placeholder="请输入交易密码"></u-input>
			</view>
		</view>
	</u-modal>
</template>

<script setup>
	import {
		ref,
		watch
	} from 'vue';
	const props = defineProps({
		payVisible: Boolean,
	});
	const emits = defineEmits(['close', 'confirm']);
	const show = ref(false);
	const password = ref('');

	function clickConfirm() {
		if (!password.value) return proxy.Pub.msg('请输入交易密码');
		emits('confirm', password.value);
	}
	watch(() => props.payVisible, (val) => {
		show.value = val;
	})
</script>

<style>

</style>