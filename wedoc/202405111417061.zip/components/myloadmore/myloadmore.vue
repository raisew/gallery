<template>
	<view class="pdt-24 pdb-24">
		<u-loadmore :status="status" :icon-type="loadmoreData.iconType" :load-text="loadmoreData.loadText"
			bg-color="transparent" font-size="24" color="#bbb" @click="$emit('loadMore')" />
	</view>
</template>

<script setup>
	import {
		reactive
	} from "vue";
	const props = defineProps({
		status: String,
	})
	const emits = defineEmits(['loadMore'])
	const loadmoreData = reactive({
		iconType: 'flower',
		loadText: {
			loadmore: '加载更多',
			loading: '努力加载中···',
			nomore: '没有更多了'
		}
	})
</script>

<style>

</style>