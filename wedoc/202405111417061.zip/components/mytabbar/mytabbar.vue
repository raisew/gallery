<template>
	<tabbar v-model="pageData.current" :list="pageData.list" :mid-button="false" :border-top="false"
		active-color="#257DEF" inactive-color="#747E98" :hide-tab-bar="true" className="box-shadow-footer bgc-footer">
	</tabbar>
</template>

<script setup>
	import {
		reactive,
		getCurrentInstance
	} from "vue";
	const {
		proxy
	} = getCurrentInstance();

	const props = defineProps({
		index: [String, Number]
	})
	const pageData = reactive({
		list: [{
				iconPath: '/static/images/tabbar/home.png',
				selectedIconPath: '/static/images/tabbar/home_active.png',
				text: '',
				customIcon: false,
				pagePath: '/pages/index/index',
			},
			{
				iconPath: '/static/images/tabbar/intro.png',
				selectedIconPath: '/static/images/tabbar/intro_active.png',
				text: '',
				customIcon: false,
				pagePath: '/pages/index/index',
			},
			{
				iconPath: '/static/images/tabbar/assets.png',
				selectedIconPath: '/static/images/tabbar/assets_active.png',
				text: '',
				customIcon: false,
				pagePath: '/pages/index/index',
			},
			{
				iconPath: '/static/images/tabbar/service.png',
				selectedIconPath: '/static/images/tabbar/service_active.png',
				text: '',
				customIcon: false,
				pagePath: '/pages/index/index',
			},
			{
				iconPath: '/static/images/tabbar/mine.png',
				selectedIconPath: '/static/images/tabbar/mine_active.png',
				text: '',
				customIcon: false,
				pagePath: '/pages/index/index',
			}
		],
		current: props.index || ''
	})
</script>

<style lang="scss">
	:deep(.u-tabbar__content__item__button) {
		top: 12rpx !important;
	}

	:deep(.u-tabbar__content__item__text) {
		bottom: 12rpx !important;
	}
</style>