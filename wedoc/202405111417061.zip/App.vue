<script setup>
	import {
		onLaunch,
		onShow,
		onHide,
	} from "@dcloudio/uni-app"
	import {
		ref,
		getCurrentInstance
	} from "vue"

	const {
		proxy
	} = getCurrentInstance();

	onLaunch(() => {
		console.log('App Launch')
		uni.hideTabBar();
		proxy.Pub.exitApp();
	})
	onShow(() => {
		console.log('App Show')

	})
	onHide(() => {
		console.log('App Hide')
	})
</script>


<style>
	@import 'animate.css';

	page {
		background-color: transparent;
		min-height: 100%;
		max-width: 540px;
		margin-left: auto;
		margin-right: auto;

	}
</style>
<style lang="scss">
	@import '@/uni_modules/uv-ui-tools/index.scss';
	@import "@/styles/scss/global.scss";
	@import "@/styles/scss/theme.scss";
	@import "@/styles/scss/custom.scss";


	view,
	text {
		box-sizing: border-box;
	}

	input {
		background-color: transparent;
	}

	.arba {
		direction: rtl;
	}

	// .bg-main {
	// 	background: url('/static/images/img/bg_main.png') no-repeat;
	// 	background-size: 100% auto;
	// 	background-position: 50% 0;
	// 	background-attachment: fixed;

	// }

	// .bg-lead {
	// 	background: url('/static/images/img/bg_lead.png') no-repeat;
	// 	background-size: 100% 100%;
	// 	background-position: 50% 0;
	// 	background-attachment: fixed;
	// }

	// .bg-login {
	// 	background: url('/static/images/img/bg_login.png') no-repeat;
	// 	background-size: 100% auto;
	// 	background-position: 50% 0;
	// 	background-attachment: fixed;
	// }

	// .bg-invite {
	// 	background: url('/static/images/img/bg_invite.png') no-repeat;
	// 	background-size: 100% auto;
	// 	background-position: 50% 0;
	// 	background-attachment: fixed;
	// }

	// @media (min-width: 540px) {

	// 	.bg-main,
	// 	.bg-lead,
	// 	.bg-login,
	// 	.bg-invite {
	// 		background-attachment: scroll !important;
	// 	}
	// }
</style>