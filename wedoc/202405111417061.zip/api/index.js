import http from "./http.js"
import apis from './apis.js'
const apiFuns = {};
apis.forEach(item => {
	let obj = {}
	switch (item.method) {
		case 'get':
			obj[item.name] = (params) => {
				return http.get(item.url, params, {
					loading: item.loading || false
				});
			}
			break;
		case 'post':
			obj[item.name] = (params) => {
				return http.post(item.url, params, {
					loading: item.loading || false
				});
			}
			break;
		case 'postFile':
			obj[item.name] = (file, params) => {
				return http.postFile(file, params, item.url);
			}
			break;
		default:
			obj[item.name] = (params) => {
				return http.post(item.url, params, {
					loading: item.loading || false
				});
			}
			break;
	}
	Object.assign(apiFuns, obj)
})
console.log(apiFuns)

export default apiFuns;