import App from './App'

import uvUI from '@/uni_modules/uv-ui-tools'

import store from './store'
import $config from "./config/index.js"
import Pub from "./utils/index.js"
import Api from "./api/index.js"
import i18n from "./locales/i18n.js"

import comTabbar from './components/com-tabbar/com-tabbar.vue'

// import './utils/intercept.js'

// #ifndef VUE3
import Vue from 'vue'
import './uni.promisify.adaptor'
Vue.config.productionTip = false
App.mpType = 'app'
Vue.use(uvUI);
const app = new Vue({
	...App
})
app.$mount()
// #endif

// #ifdef VUE3
import {
	createSSRApp
} from 'vue'
export function createApp() {
	const app = createSSRApp(App)
	app.component('comTabbar', comTabbar);
	app.config.globalProperties.Pub = Pub;
	app.config.globalProperties.$config = $config;
	app.config.globalProperties.$api = Api;
	app.use(i18n)
	app.use(store)
	app.use(uvUI);
	return {
		app
	}
}
// #endif