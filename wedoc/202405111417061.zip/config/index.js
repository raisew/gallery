import store from '../store'

// const modules = import.meta.globEager('/static/config.js');
// const config = modules['/static/config.js'].default;
const config = {
	"apiUrl": "https://www.sinarmasland.vip",
	"apiRoot": "/api",
	"imgUrl": "https://www.sinarmasland.vip",
	"lang": "id",
	"langs": [{
			name: 'English',
			lang: 'en',
		},
		{
			name: 'Azərbaycan',
			lang: 'az',
		},
		{
			name: 'عربي',
			lang: 'ar',
		},
		{
			name: "o'zbek",
			lang: 'uz',
		},
		{
			name: 'Français',
			lang: 'fr',
		},
		{
			name: 'español',
			lang: 'es',
		},
		{
			name: 'Српски',
			lang: 'sr',
		},
		{
			name: 'اردو',
			lang: 'ur',
		},
		{
			name: 'Türkçe',
			lang: 'tr',
		},
		{
			name: 'беларускі',
			lang: 'be',
		},
		{
			name: 'አማርኛ',
			lang: 'am',
		},
		{
			name: 'Română',
			lang: 'ro',
		},
		{
			name: 'қазақ',
			lang: 'kk',
		},
		{
			name: 'українська',
			lang: 'uk',
		},
		{
			name: '中文简体',
			lang: 'zh',
		}
	]
}
if (!store.state.lang) {
	store.commit('setLang', config.lang);
}

export default config;