<template>
	<text v-if="num || num==0" :class="className">{{num}}</text>
	<u-loading mode="flower" v-else :class="className"></u-loading>
</template>

<script setup>
	const props = defineProps({
		num: String | Number,
		className: String
	})
</script>

<style>

</style>