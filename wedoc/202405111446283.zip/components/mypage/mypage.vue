<template>
	<view class="mypage" :style="{'min-height': winMinHeight + 'px'}" :class="`theme-${themeName}`">
		<view class="page bgc-base bg-main" :style="{'min-height': winMinHeight + 'px'}" :class="className">
			<slot></slot>
		</view>
	</view>
</template>

<script setup>
	import {
		useStore
	} from "vuex";
	import {
		ref,
		computed,
		onMounted,
		getCurrentInstance
	} from "vue";

	const {
		proxy
	} = getCurrentInstance();
	const store = useStore();
	const themeName = computed(() => store.state.themeName);
	const props = defineProps({
		className: String
	});
	const winMinHeight = ref(proxy.Pub.winInfo().windowHeight);
	uni.onWindowResize(() => {
		winMinHeight.value = proxy.Pub.winInfo().windowHeight;
	})
</script>

<style lang="scss">
	.mypage {
		min-height: 100vh;
	}

	.page {
		width: 100%;
		min-height: 100vh;
		overflow-x: hidden;
		// -webkit-overflow-scrolling: touch;
	}
</style>