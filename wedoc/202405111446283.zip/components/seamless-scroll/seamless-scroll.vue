<template>
	<view class="scroll-container" :style="{height: height + 'px'}">
		<view class="scroll-content" :style="{transform: 'translateY(-' + translateY + 'px)'}" ref="contentRef">
			<slot></slot>
		</view>
	</view>
</template>

<script setup>
	import {
		ref,
		onMounted,
		onUnmounted,
	} from 'vue';

	const props = defineProps({
		height: {
			type: Number,
			default: 400,
		},
		speed: {
			type: Number,
			default: 100,
		}
	});

	const translateY = ref(0); // Y轴位移
	let contentRef = ref(null);
	let contentHeight = 0;
	let previousTime = null;

	let rafId;

	function startScroll() {
		function animateScroll(timestamp) {
			if (!previousTime) {
				previousTime = timestamp;
			}
			const elapsedTime = timestamp - previousTime;
			if (elapsedTime > 1000 / props.speed) {
				translateY.value += 1;
				if (translateY.value >= contentHeight - props.height) {
					translateY.value = 0;
				}
				previousTime = timestamp;
			}
			rafId = requestAnimationFrame(animateScroll);
		}
		rafId = requestAnimationFrame(animateScroll);
	}

	onMounted(() => {
		contentHeight = contentRef.value.$el.scrollHeight;
		startScroll();
	});

	onUnmounted(() => {
		cancelAnimationFrame(rafId);
	});
</script>

<style scoped>
	.scroll-container {
		overflow: hidden;
	}
</style>