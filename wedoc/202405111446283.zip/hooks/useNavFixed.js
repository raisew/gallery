import {
	reactive,
	computed,
	getCurrentInstance,
	ref,
	nextTick
} from "vue";
import {
	onShow,
	onLoad,
	onPageScroll
} from "@dcloudio/uni-app"

function useNavFixed(el) {
	const {
		proxy
	} = getCurrentInstance();
	const isFixed = ref(false);
	const scrollTop = ref(0);
	const navHeight = ref(0);
	const getNavHeight = async () => {
		const data = await proxy.Pub.getNodeInfo(el);
		navHeight.value = data?.height;
	}
	onLoad(() => {
		nextTick(() => {
			getNavHeight();
		})
	})

	onShow(() => {
		isFixed.value = false;
		setTimeout(() => {
			uni.pageScrollTo({
				scrollTop: 0,
				duration: 0
			})
		}, 0)

	})
	onPageScroll((e) => {
		scrollTop.value = e.scrollTop;
		if (scrollTop.value > navHeight.value) {
			isFixed.value = true;
		} else {
			isFixed.value = false;
		}
	})

	return {
		isFixed,
		scrollTop,
	}
}

export default useNavFixed;