import config from '../config/index.js';
import Pub from "../utils/index.js"
import store from "../store/index.js"
import sign from "../utils/sign.js"

import i18n from "@/locales/i18n.js"
const lang = i18n.global;


const http = {
	interceptor: {
		request: (config) => {
			return config;
		},
		response: (response) => {
			console.log(response)
			let {
				statusCode,
				errMsg,
				data
			} = response;
			if (statusCode !== 200) {
				console.log(errMsg);
				return response
			}
			if (typeof data == 'string') {
				data = JSON.parse(data);
			}
			return data;
		}
	},
	request(options) {

		if (options.url && options.url.indexOf('http') == -1) {
			options.url = config.apiUrl + config.apiRoot + options.url;
		}
		let header = {
			// "content-type": "application/json",
			"content-type": "application/x-www-form-urlencoded",
			// "token": store.state.token,
			// "lang": store.state.lang,
		}
		options.method = options.method || 'GET';
		options.data = options.data || {};
		options.data.lastsession = store.state.token;
		options.header = {
			...options.header,
			...header
		};
		options.loading = !options.loading ? false : true;
		options.requestTime = options.requestTime || 500;
		options.dataType = options.dataType || 'json';
		let loadingStatus = true;
		if (loadingStatus && options.loading) {
			uni.showLoading({
				// title: "加载中",
				mask: true
			})
		}
		return new Promise((resolve, reject) => {
			if (!this.interceptor.request(options)) {
				return;
			}
			//请求接口日志记录
			_reqlog(options)
			uni.request({
				url: options.url,
				method: options.method,
				data: options.data,
				header: options.header,
				dataType: options.dataType,
				success: (response) => {
					let statusCode = response.statusCode;
					let res = this.interceptor.response(response);
					if (statusCode == 200) {
						if (res.status != 1 && res.status != -1) {
							Pub.msg(res.msg)
						}
						if (res.status == -1) {
							uni.redirectTo({
								url: '/pages/startup/startup'
							})
						}
						//接口响应日志
						_reslog(res)
						resolve(res);
					}
				},
				fail(error) {
					Pub.msg(lang.t('Network_error'));
					console.log(error)
					resolve({});
				},
				complete(cpt) {
					if (loadingStatus && options.loading) {
						uni.hideLoading();
					}
					loadingStatus = false;
					if (cpt.statusCode == 401) {
						Pub.setStore('rmStore');
						Pub.msg(cpt.data.msg).then(() => {
							Pub.toLogin();
						})
					} else if (cpt.statusCode == 818) {
						resolve(cpt.data)
					}
				}

			})
		});
	},
	get(url, data, options) {
		if (!options) options = {}
		options.url = url
		options.data = data
		options.method = 'GET'
		return this.request(options)
	},
	delete(url, data, options) {
		if (!options) options = {}
		options.url = url
		options.data = data
		options.method = 'DELETE'
		return this.request(options)
	},
	put(url, data, options) {
		if (!options) options = {}
		options.url = url
		options.data = data
		options.method = 'PUT'
		return this.request(options)
	},
	post(url, data, options) {
		if (!options) options = {}
		options.url = url;
		options.data = data;
		options.header = options.header || {
			'content-type': 'application/json;charset=UTF-8'
		}
		options.method = 'POST'
		return this.request(options)
	},
	postForm(url, data) {
		return this.post(url, data, {
			header: {
				'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'
			}
		})
	},
	postFile(file, params, url) {
		let _this = this;
		uni.showLoading({
			// title: "加载中",
			mask: true
		})
		let header = {
			// "Content-Type": "multipart/form-data",
			// "Authorization": "bearer " + store.state.token,
		}
		let fileParams = {}
		// #ifdef H5
		fileParams = {
			file: file,
		}
		// #endif
		// #ifndef H5
		fileParams = {
			filePath: file,
		}
		// #endif
		let data = params || {};
		data.lastsession = store.state.token;
		return new Promise((resolve, reject) => {
			uni.uploadFile({
				url: `${config.apiUrl}${config.apiRoot}${url}`, //上传 // 后端上传接口地址
				// filePath: res2, // 需要上传的文件本地路径
				name: data.fileName || 'file', // 后端接收的文件字段名
				...fileParams,
				header: {
					...header
				},
				formData: data,
				success: function(response) {
					console.log(response)
					let statusCode = response.statusCode;
					let res = _this.interceptor.response(response);
					if (statusCode == 200) {
						if (res.code != 1) {
							Pub.msg(res.msg)
						}
						//接口响应日志
						_reslog(res)
						resolve(res)
					} else {
						reject(res)
					}
				},
				fail: function(err) {
					console.log("upload failed", err);
					Pub.msg('上传失败,请重试');
					// reject(err);
				},
				complete: function(cpt) {
					uni.hideLoading();
					if (cpt.statusCode == 401) {
						Pub.setStore('rmStore');
						Pub.msg(cpt.data?.msg).then(() => {
							Pub.toLogin();
						})
					}
				}
			});

		})
	},

}


/**
 * 请求接口日志记录
 */
const _reqlog = (req) => {
	if (process.env.NODE_ENV === 'development') {
		console.log("请求地址：" + req.url)
		if (req.data) {
			console.log("请求参数：" + JSON.stringify(req.data))
		}
	}
}
/**
 * 响应接口日志记录
 */
const _reslog = (res) => {
	let _statusCode = res.code;
	if (process.env.NODE_ENV === 'development') {
		console.log("响应结果：" + JSON.stringify(res))
	}
}

export default http;