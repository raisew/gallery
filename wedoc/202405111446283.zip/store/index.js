import {
	createStore
} from 'vuex'
import getters from './getters'
import actions from './actions'
import mutations from './mutations'
import state from './state'
import VuexPersistence from 'vuex-persist'

const vuexLocal = new VuexPersistence({
	key: 'apex',
	storage: {
		getItem: key => uni.getStorageSync(key),
		setItem: (key, value) => uni.setStorageSync(key, value),
		removeItem: key => uni.removeStorageSync(key)
	}
})
// 调用createStore
export default createStore({
	state,
	getters,
	actions,
	mutations,
	plugins: [vuexLocal.plugin]
})