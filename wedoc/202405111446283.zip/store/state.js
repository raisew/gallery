const state = {
	token: '',
	lang: '',
	themeName: 'light',
	assetVisible: false,
	configData: {},
	userinfo: {},
}
export default state