// import zh from "./lang/zh.js"
// import en from "./lang/en.js"
// import id from "./lang/id.js"

// export default {
// 	'zh': zh,
// 	'en': en,
// 	'id': id,
// }

// const languages = ["en", "id", "zh"]

// const langModules = {}
// for (const lang of languages) {
// 	import(`./lang/${lang}.js`).then(module => {
// 		langModules[lang] = module.default
// 	})
// }

// export default langModules

const modules = {};
const files = import.meta.glob('./lang/*.js', {
	import: 'default',
	eager: true,
});
for (const path in files) {
	const moduleName = path.replace(/^\.\/lang\/(.*)\.js$/, '$1');
	const module = files[path];
	modules[moduleName] = module;
}
export default modules;