import {
	createI18n
} from 'vue-i18n'
import messages from "./index";
import store from '../store';
const i18n = createI18n({
	legacy: false,
	locale: store.state.lang,
	globalInjection: true,
	fallbackLocale: 'id',
	messages
})
export default i18n